#version 330 core

// ---------------------------------------------------------------------------
// Bounding-box wireframe vertex shader – simple MVP transform
// ---------------------------------------------------------------------------

layout(location = 0) in vec3 aPosition;

uniform mat4 uView;
uniform mat4 uProjection;

void main() {
    gl_Position = uProjection * uView * vec4(aPosition, 1.0);
}
