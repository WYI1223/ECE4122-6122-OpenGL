# ECE 4122/6122 – Final Project: 3D Particle Simulation (Skeleton)

A real-time 3D particle system built with **OpenGL 3.3 Core Profile**, **C++17**,
**GLFW**, **GLEW**, **GLM**, and **OpenMP**.

---

## Your Task

All five `.cpp` source files contain `TODO` comments marking the code you must write.
The headers (`.h` files), shaders, config file, and `CMakeLists.txt` are already
complete — **do not modify them**.

### Files to implement

| File | What you implement |
|---|---|
| `src/Particle.cpp` | `init()`, `update()` (semi-implicit Euler), `collideBounds()` |
| `src/ParticleEmitter.cpp` | Constructor, `update()` (emission + OpenMP physics + harvest), `spawnOne()`, three velocity helpers, `cycleEmitterType()`, `emitterTypeName()` |
| `src/Renderer.cpp` | `init()` (VAO/VBO setup), `draw()`, `drawParticles()`, `drawBBox()`, shader helpers (`readFile`, `compileShader`, `linkProgram`, `loadShaders`) |
| `src/Camera.cpp` | `init()`, `position()`, `getViewMatrix()`, `getProjectionMatrix()`, all mouse/scroll/key callbacks |
| `src/SimulationConfig.cpp` | `trim()` helper, `load()` INI parser |

`src/main.cpp` is fully provided — it wires everything together and runs the main loop.

---

## Features to Implement

| Feature | Details |
|---|---|
| **OOP Architecture** | Five custom classes: `Particle`, `ParticleEmitter`, `Renderer`, `Camera`, `SimulationConfig` |
| **Rule-of-Five** | All resource-owning classes define or delete copy/move constructors and assignment operators (headers already handle this) |
| **Emitter Modes** | Fountain, Cyclic Explosion, Vortex — switchable at runtime |
| **Physics** | Semi-implicit Euler integration; gravity; axis-aligned boundary reflection with configurable restitution |
| **Parallel Update** | OpenMP `#pragma omp parallel for` over the particle pool; thread count set in INI |
| **Memory Management** | Fixed-capacity free-pool; dead particles recycled via `std::stack<int>` |
| **Rendering** | Point sprites with perspective-correct sizing; per-particle age-based colour gradient |
| **Camera** | Orbital arc-ball; left-drag orbit, right-drag pan, scroll zoom |
| **Config** | INI file parsed at startup; safe defaults if file is missing |

---


> **Tip:** The project will compile from the skeleton but won't display anything
> until you implement `Renderer::init()` and `ParticleEmitter::update()`.
> Start with `SimulationConfig`, then `Particle`, then build up from there.

---

## Controls

| Input | Action |
|---|---|
| **Left-drag** | Orbit camera |
| **Right-drag** | Pan camera target |
| **Scroll wheel** | Zoom in / out |
| **R** | Reset camera to default view |
| **1** | Switch to Fountain mode |
| **2** | Switch to Explosion mode |
| **3** | Switch to Vortex mode |
| **TAB** | Cycle through emitter modes |
| **SPACE** | Pause / Resume simulation |
| **ESC** | Quit |

---

## Architecture

```
src/
  SimulationConfig.h/.cpp   – INI parser; plain-data config struct
  Particle.h/.cpp           – Per-particle state; semi-implicit Euler update
  ParticleEmitter.h/.cpp    – Pool manager; OpenMP physics; free-list recycling
  Camera.h/.cpp             – Orbital camera; GLFW input handlers
  Renderer.h/.cpp           – RAII OpenGL resources; point-sprite draw calls
  main.cpp                  – Window/context setup; main loop (PROVIDED)
shaders/
  particle.vert / .frag     – Point-sprite rendering with colour gradient (PROVIDED)
  bbox.vert    / .frag      – Wireframe bounding-box (PROVIDED)
config/
  simulation.ini            – Runtime parameters (PROVIDED)
```

---

## Suggested Implementation Order

1. **`SimulationConfig::load()`** — pure string parsing, no graphics needed
2. **`Particle::init()`, `update()`, `collideBounds()`** — core physics, unit-testable
3. **`Camera`** — math only (GLM), no OpenGL
4. **`ParticleEmitter` constructor + `emitterTypeName()` + `cycleEmitterType()`**
5. **`Renderer` shader helpers** (`readFile`, `compileShader`, `linkProgram`, `loadShaders`)
6. **`Renderer::init()`** — VAO/VBO setup
7. **`Renderer::setBoundingBox()` + `drawBBox()`** — visible wireframe box
8. **`ParticleEmitter::update()`** — emission + OpenMP physics
9. **`Renderer::drawParticles()`** — particles on screen

---

## Integrator Reference

Use **semi-implicit (symplectic) Euler** in `Particle::update()`:

```
velocity(t+dt) = velocity(t) + (gravity + acceleration) * dt   // velocity FIRST
position(t+dt) = position(t) + velocity(t+dt) * dt             // use NEW velocity
```

---

## Configuration (`config/simulation.ini`)

Edit `config/simulation.ini` to tune the simulation without recompiling:

```ini
[simulation]
max_particles = 30000   ; pool size (pre-allocated)
spawn_rate    = 2500    ; particles / second
num_threads   = 8       ; OpenMP workers

[physics]
gravity_y   = -9.81
restitution = 0.65

[emitter]
emitter_type = 0        ; 0=Fountain 1=Explosion 2=Vortex
```
