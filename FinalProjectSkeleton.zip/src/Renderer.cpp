#include "Renderer.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <utility>
#include <array>
#include <glm/gtc/type_ptr.hpp>

// =============================================================================
// Renderer.cpp  –  ECE 4122/6122 Final Project  (STUDENT SKELETON)
// =============================================================================
// The Renderer encapsulates ALL OpenGL state for the simulation.
// You must implement the functions marked TODO below.
//
// The class owns two shader programs (particle and bounding-box) and two
// VAO/VBO pairs.  All GPU resources are freed in the destructor via release().
//
// OpenGL concepts used here:
//   VAO  – Vertex Array Object: remembers attribute layout
//   VBO  – Vertex Buffer Object: stores geometry on the GPU
//   Shader program: compiled GLSL vertex + fragment shader pair
//   glBufferData / glBufferSubData: upload data to a VBO
//   glVertexAttribPointer: describe one attribute within a VBO
//   glDrawArrays(GL_POINTS, …): draw one point per vertex
//   glDrawArrays(GL_LINES,  …): draw line segments (two vertices per edge)
//
// The header (Renderer.h) is already complete – do NOT modify it.
// =============================================================================


// ---------------------------------------------------------------------------
// Move constructor / move-assignment / destructor
//   These are provided for you – they handle RAII ownership transfer.
//   You do NOT need to modify them, but read them to understand the pattern.
// ---------------------------------------------------------------------------
Renderer::Renderer(Renderer&& o) noexcept
    : m_particleProgram(o.m_particleProgram),
      m_bboxProgram    (o.m_bboxProgram),
      m_particleVAO   (o.m_particleVAO),
      m_particleVBO   (o.m_particleVBO),
      m_bboxVAO       (o.m_bboxVAO),
      m_bboxVBO       (o.m_bboxVBO),
      m_maxParticles  (o.m_maxParticles),
      m_staging       (std::move(o.m_staging)),
      m_initialised   (o.m_initialised)
{
    o.m_particleProgram = o.m_bboxProgram = 0;
    o.m_particleVAO = o.m_particleVBO = 0;
    o.m_bboxVAO     = o.m_bboxVBO    = 0;
    o.m_initialised = false;
}

Renderer& Renderer::operator=(Renderer&& o) noexcept {
    if (this != &o) {
        release();
        m_particleProgram = o.m_particleProgram;
        m_bboxProgram     = o.m_bboxProgram;
        m_particleVAO     = o.m_particleVAO;
        m_particleVBO     = o.m_particleVBO;
        m_bboxVAO         = o.m_bboxVAO;
        m_bboxVBO         = o.m_bboxVBO;
        m_maxParticles    = o.m_maxParticles;
        m_staging         = std::move(o.m_staging);
        m_initialised     = o.m_initialised;
        o.m_particleProgram = o.m_bboxProgram = 0;
        o.m_particleVAO = o.m_particleVBO = 0;
        o.m_bboxVAO     = o.m_bboxVBO    = 0;
        o.m_initialised = false;
    }
    return *this;
}

Renderer::~Renderer() { release(); }


// ---------------------------------------------------------------------------
// release()  –  PROVIDED: frees all GPU resources
// ---------------------------------------------------------------------------
void Renderer::release() noexcept {
    if (m_particleVBO) { glDeleteBuffers(1, &m_particleVBO); m_particleVBO = 0; }
    if (m_particleVAO) { glDeleteVertexArrays(1, &m_particleVAO); m_particleVAO = 0; }
    if (m_bboxVBO)     { glDeleteBuffers(1, &m_bboxVBO); m_bboxVBO = 0; }
    if (m_bboxVAO)     { glDeleteVertexArrays(1, &m_bboxVAO); m_bboxVAO = 0; }
    if (m_particleProgram) { glDeleteProgram(m_particleProgram); m_particleProgram = 0; }
    if (m_bboxProgram)     { glDeleteProgram(m_bboxProgram);     m_bboxProgram     = 0; }
    m_initialised = false;
}


// ---------------------------------------------------------------------------
// Renderer::init
//   Call once after an OpenGL context is current.
//   Returns true on success, false on any shader/buffer error.
//
//   Steps:
//     1. Store maxParticles; reserve m_staging.
//     2. Load the particle shader pair  → m_particleProgram
//     3. Load the bbox shader pair      → m_bboxProgram
//     4. Create the PARTICLE VAO/VBO:
//          glGenVertexArrays / glGenBuffers
//          glBindVertexArray, glBindBuffer(GL_ARRAY_BUFFER, …)
//          glBufferData with size = maxParticles * sizeof(ParticleVertex),
//                         data = nullptr, usage = GL_STREAM_DRAW
//          Set up three vertex attributes using glVertexAttribPointer:
//            location 0 – vec3  aPosition  (offset of ParticleVertex::position)
//            location 1 – vec4  aColor     (offset of ParticleVertex::color)
//            location 2 – float aSize      (offset of ParticleVertex::size)
//          Unbind VAO and VBO.
//     5. Create the BBOX VAO/VBO:
//          24 vec3 vertices (12 edges × 2 endpoints), usage = GL_DYNAMIC_DRAW
//          One attribute: location 0 – vec3 (full stride = sizeof(glm::vec3))
//          Unbind.
//     6. Set m_initialised = true, print "[Renderer] Initialised OK."
// ---------------------------------------------------------------------------
bool Renderer::init(int maxParticles,
                    const std::string& pVert, const std::string& pFrag,
                    const std::string& bVert, const std::string& bFrag)
{
    m_maxParticles = maxParticles;
    m_staging.reserve(maxParticles);

    // TODO: load particle shaders  → m_particleProgram
    // TODO: load bbox shaders      → m_bboxProgram

    // TODO: create particle VAO/VBO and define three vertex attributes

    // TODO: create bbox VAO/VBO (24 vec3 vertices, GL_DYNAMIC_DRAW)

    // TODO: set m_initialised = true and print status
    return false; // replace with true once implemented
}


// ---------------------------------------------------------------------------
// Renderer::setBoundingBox
//   Build the 24 edge-endpoint vertices (12 edges of an AABB) and upload
//   them to the bbox VBO with glBufferSubData.
//
//   The 12 edges (bottom face, top face, 4 vertical pillars) as pairs:
//     Bottom: (mn.x,mn.y,mn.z)↔(mx.x,mn.y,mn.z), (mx.x,mn.y,mn.z)↔(mx.x,mn.y,mx.z),
//             (mx.x,mn.y,mx.z)↔(mn.x,mn.y,mx.z), (mn.x,mn.y,mx.z)↔(mn.x,mn.y,mn.z)
//     Top:    same pattern at my = mx.y
//     Pillars: each bottom corner connected to the corresponding top corner
// ---------------------------------------------------------------------------
void Renderer::setBoundingBox(const glm::vec3& mn, const glm::vec3& mx)
{
    // TODO: build std::array<glm::vec3, 24> verts with all 12 edge pairs
    // TODO: glBindBuffer / glBufferSubData / glBindBuffer(0)
}


// ---------------------------------------------------------------------------
// Renderer::draw
//   Main per-frame render call.
//
//   Steps:
//     1. Guard: return if !m_initialised.
//     2. Clear: glClearColor(0.02, 0.02, 0.06, 1); glClear(COLOR|DEPTH).
//     3. Draw the bounding box (opaque, depth writes on) – call drawBBox.
//     4. Draw particles (additive blending, depth writes off) – call drawParticles.
// ---------------------------------------------------------------------------
void Renderer::draw(const std::vector<Particle>& pool,
                    const glm::mat4& view,
                    const glm::mat4& proj,
                    float screenHeight)
{
    if (!m_initialised) return;

    // TODO: set clear colour and clear colour + depth buffers

    // TODO: call drawBBox(view, proj)
    // TODO: call drawParticles(pool, view, proj, screenHeight)
}


// ---------------------------------------------------------------------------
// Renderer::drawParticles  (private)
//   1. Build m_staging: iterate pool, skip dead particles, push ParticleVertex
//      {p.position, p.currentColor(), p.size} for each alive particle.
//   2. Return early if m_staging is empty.
//   3. Upload to GPU:
//        glBindBuffer(GL_ARRAY_BUFFER, m_particleVBO)
//        glBufferData(… maxParticles * sizeof(ParticleVertex), nullptr, GL_STREAM_DRAW)
//        glBufferSubData(… m_staging.size() * sizeof(ParticleVertex), m_staging.data())
//   4. Enable GL_PROGRAM_POINT_SIZE.
//   5. Use m_particleProgram; set uniforms uView, uProjection, uScreenHeight.
//   6. Bind m_particleVAO; glDrawArrays(GL_POINTS, 0, staging.size()); unbind.
//   7. Restore state: disable GL_PROGRAM_POINT_SIZE.
// ---------------------------------------------------------------------------
void Renderer::drawParticles(const std::vector<Particle>& pool,
                              const glm::mat4& view,
                              const glm::mat4& proj,
                              float screenHeight)
{
    // TODO: build m_staging from alive particles

    // TODO: return early if m_staging is empty

    // TODO: orphan the VBO and upload m_staging

    // TODO: set blend / depth state, bind program and uniforms, draw, restore state
}


// ---------------------------------------------------------------------------
// Renderer::drawBBox  (private)
//   Use m_bboxProgram.
//   Set uniforms: uView, uProjection, uColor (suggest rgba 0.25, 0.35, 0.55, 1).
//   Bind m_bboxVAO; glDrawArrays(GL_LINES, 0, 24); unbind.
// ---------------------------------------------------------------------------
void Renderer::drawBBox(const glm::mat4& view, const glm::mat4& proj)
{
    // TODO: use m_bboxProgram, set uniforms, draw 24 line vertices
}


// ===========================================================================
// Shader helper methods  –  implement these utilities used by init()
// ===========================================================================

// ---------------------------------------------------------------------------
// readFile  –  read a text file from disk into a std::string.
//              Print an error and return {} if the file cannot be opened.
// ---------------------------------------------------------------------------
std::string Renderer::readFile(const std::string& path)
{
    // TODO: open path with std::ifstream; stream contents into std::ostringstream
    //       return the string, or {} on failure
    return {};
}

// ---------------------------------------------------------------------------
// compileShader  –  create a GL shader of the given type, attach src, compile.
//                   On failure print the info log and return 0.
// ---------------------------------------------------------------------------
GLuint Renderer::compileShader(GLenum type, const std::string& src)
{
    // TODO: glCreateShader, glShaderSource, glCompileShader
    //       check GL_COMPILE_STATUS; on error print log and return 0
    return 0;
}

// ---------------------------------------------------------------------------
// linkProgram  –  attach vert + frag to a new program object and link.
//                 On failure print the info log and return 0.
//                 Detach shaders after a successful link.
// ---------------------------------------------------------------------------
GLuint Renderer::linkProgram(GLuint vert, GLuint frag)
{
    // TODO: glCreateProgram, attach, link, check GL_LINK_STATUS
    //       detach shaders; on error return 0
    return 0;
}

// ---------------------------------------------------------------------------
// loadShaders  –  convenience wrapper: read both files, compile, link.
//                 Stores the resulting program in outProgram.
//                 Returns false on any error.
// ---------------------------------------------------------------------------
bool Renderer::loadShaders(const std::string& vertPath, const std::string& fragPath,
                            GLuint& outProgram)
{
    // TODO: call readFile for both paths (return false if either is empty)
    // TODO: compile both shaders (return false and clean up if either fails)
    // TODO: link; return true if successful
    return false;
}
